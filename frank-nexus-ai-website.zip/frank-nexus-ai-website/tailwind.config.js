/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'holo-orange': '#ff6b00',
        'dark-bg': '#0a0a0f',
        'glass': 'rgba(255, 255, 255, 0.04)',
      }
    },
  },
  plugins: [],
}