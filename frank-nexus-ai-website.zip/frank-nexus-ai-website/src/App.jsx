import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Brain, Mic, Shield, FolderOpen, BarChart3, Settings, 
  Download, Users, ArrowRight, Play, Star 
} from 'lucide-react';

// Navigation Component
const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-[#ff6b00] to-[#f59e0b] rounded-xl flex items-center justify-center">
            <Brain className="w-5 h-5 text-[#0a0a0f]" />
          </div>
          <div>
            <div className="font-bold text-xl tracking-tighter">FRANK-NEXUS</div>
            <div className="text-[10px] text-[#ff6b00]/70 -mt-1">AI v1.0</div>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8 text-sm">
          <Link to="/" className="hover:text-[#ff6b00] transition-colors">Home</Link>
          <Link to="/features" className="hover:text-[#ff6b00] transition-colors">Features</Link>
          <Link to="/screenshots" className="hover:text-[#ff6b00] transition-colors">Screenshots</Link>
          <Link to="/download" className="hover:text-[#ff6b00] transition-colors">Download</Link>
          <Link to="/about" className="hover:text-[#ff6b00] transition-colors">About</Link>
          <Link to="/privacy" className="hover:text-[#ff6b00] transition-colors">Privacy</Link>
          <Link to="/contact" className="hover:text-[#ff6b00] transition-colors">Contact</Link>
        </div>

        <div className="flex items-center gap-4">
          <a 
            href="https://github.com/yourusername/frank-nexus-ai" 
            target="_blank" 
            className="hidden md:block text-sm px-5 py-2 rounded-xl border border-white/20 hover:bg-white/5 transition-all"
          >
            GitHub
          </a>
          <Link 
            to="/download" 
            className="btn-primary px-6 py-2.5 rounded-2xl text-sm font-medium flex items-center gap-2"
          >
            Download <Download className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </nav>
  );
};

// Home / Hero
const Home = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20">
      {/* Hero */}
      <div className="max-w-5xl mx-auto px-6 pt-20 pb-24 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#ff6b00]/30 bg-[#ff6b00]/10 mb-6">
          <Star className="w-4 h-4 text-[#ff6b00]" />
          <span className="text-sm tracking-[1px] text-[#ff6b00]">VERSION 1.0 • NOW AVAILABLE</span>
        </div>

        <h1 className="text-7xl md:text-8xl font-bold tracking-tighter mb-6">
          FRANK-<span className="text-[#ff6b00]">NEXUS</span>-AI
        </h1>
        
        <p className="text-2xl md:text-3xl text-white/80 mb-4 tracking-tight">
          The Future of Intelligent Assistance
        </p>

        <p className="max-w-2xl mx-auto text-lg text-white/60 mb-12">
          Your personal AI assistant designed to help you chat, organize your day, 
          manage tasks, and interact with your devices through a modern, permission-based experience.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            to="/download" 
            className="btn-primary px-10 py-4 rounded-3xl text-lg font-medium flex items-center justify-center gap-3 group"
          >
            Download Now 
            <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link 
            to="/features" 
            className="btn-secondary px-10 py-4 rounded-3xl text-lg font-medium flex items-center justify-center gap-3"
          >
            Explore Features
          </Link>
        </div>

        {/* Enhanced Holographic AI Core with Framer Motion */}
        <div className="mt-20 flex justify-center">
          <div className="relative w-72 h-72">
            {/* Outer glow */}
            <motion.div 
              className="absolute inset-0 bg-[#ff6b00]/10 rounded-full blur-[80px]"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
            
            {/* Main holographic orb */}
            <motion.div 
              className="relative w-72 h-72 border-[3px] border-[#ff6b00]/60 rounded-full flex items-center justify-center"
              animate={{ rotate: 360 }}
              transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            >
              {/* Inner rotating energy rings */}
              <motion.div 
                className="absolute w-60 h-60 border border-[#ff6b00]/40 rounded-full"
                animate={{ rotate: -360 }}
                transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute w-48 h-48 border border-[#ff6b00]/30 rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
              />
              
              {/* Core glowing orb */}
              <div className="w-44 h-44 bg-gradient-to-br from-[#ff6b00] via-[#f59e0b] to-[#ff6b00] rounded-full flex items-center justify-center shadow-[0_0_120px_rgb(255,107,0,0.6)] relative overflow-hidden">
                <Brain className="w-24 h-24 text-[#0a0a0f] z-10" />
                
                {/* Inner hologram scan line effect */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-b from-transparent via-white/20 to-transparent"
                  animate={{ y: ["-100%", "200%"] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
                />
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Trust Bar */}
      <div className="border-t border-white/10 py-8">
        <div className="max-w-5xl mx-auto px-6 flex flex-wrap justify-center gap-x-12 gap-y-4 text-sm text-white/50">
          <div>Privacy First</div>
          <div>Permission-Based</div>
          <div>Futuristic Design</div>
          <div>Cross-Platform</div>
        </div>
      </div>
    </div>
  );
};

// Features Page
const Features = () => {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Intelligent AI Assistant",
      items: ["Natural conversations", "Memory with permission", "Planning assistance", "Study helper", "Translation & Summaries"]
    },
    {
      icon: <Mic className="w-8 h-8" />,
      title: "Voice Assistant",
      items: ["Wake word: \"Hey FRANK\"", "Natural speech-to-text", "Text-to-speech responses", "Command recognition"]
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Privacy First",
      items: ["Always asks permission", "Camera • Microphone • Files", "Photos • Contacts • Location", "You stay in complete control"]
    },
    {
      icon: <FolderOpen className="w-8 h-8" />,
      title: "Productivity Suite",
      items: ["Notes & Organization", "Calendar & Tasks", "Reminders & Notifications", "File Manager"]
    },
    {
      icon: <Settings className="w-8 h-8" />,
      title: "Owner Control Room",
      items: ["AI Settings & Memory Manager", "Permission Manager", "Activity Logs & Diagnostics", "Backup & Restore"]
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="text-[#ff6b00] text-sm tracking-[3px] mb-3">POWERFUL CAPABILITIES</div>
          <h2 className="text-5xl font-bold tracking-tighter">Everything You Need.<br />Nothing You Don't.</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              whileHover={{ y: -8 }}
              className="glass p-8 rounded-3xl border border-white/10"
            >
              <div className="text-[#ff6b00] mb-6">{feature.icon}</div>
              <h3 className="text-2xl font-semibold mb-6">{feature.title}</h3>
              <ul className="space-y-3 text-white/70">
                {feature.items.map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-1.5 w-1.5 h-1.5 bg-[#ff6b00] rounded-full flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Screenshots Page - Professional Gallery
const Screenshots = () => {
  const screenshots = [
    { 
      title: "Dashboard", 
      desc: "Clean futuristic command center with live metrics and quick access", 
      icon: BarChart3 
    },
    { 
      title: "AI Chat Interface", 
      desc: "Natural conversations with context-aware intelligent responses", 
      icon: Brain 
    },
    { 
      title: "Voice Assistant", 
      desc: "Wake word detection and seamless voice interaction", 
      icon: Mic 
    },
    { 
      title: "Owner Control Room", 
      desc: "Complete system management, settings, and diagnostics", 
      icon: Settings 
    },
    { 
      title: "Permission Center", 
      desc: "Full control over access to camera, files, microphone, and more", 
      icon: Shield 
    },
    { 
      title: "System Monitor + Analytics", 
      desc: "Real-time performance, usage statistics, and health dashboard", 
      icon: BarChart3 
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="text-[#ff6b00] text-sm tracking-[3px] mb-3">PREMIUM INTERFACE</div>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tighter mb-4">See FRANK in Action</h2>
          <p className="text-xl text-white/70 max-w-2xl mx-auto">A beautifully designed interface built for clarity, speed, and control.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {screenshots.map((shot, index) => {
            const Icon = shot.icon;
            return (
              <motion.div 
                key={index}
                whileHover={{ scale: 1.02 }}
                className="group"
              >
                <div className="aspect-video bg-gradient-to-br from-[#111] to-[#1a1a20] rounded-3xl mb-5 overflow-hidden border border-white/10 relative flex items-center justify-center">
                  {/* Professional placeholder with icon */}
                  <div className="text-center p-8">
                    <div className="mx-auto mb-4 w-16 h-16 bg-[#ff6b00]/10 rounded-2xl flex items-center justify-center border border-[#ff6b00]/30">
                      <Icon className="w-9 h-9 text-[#ff6b00]" />
                    </div>
                    <div className="text-[#ff6b00] text-xs tracking-[2px] mb-1">SCREENSHOT</div>
                    <div className="text-white/40 text-sm">Add real image here</div>
                  </div>
                  
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center">
                    <div className="text-white text-sm px-5 py-2 rounded-full border border-white/30">View Full Size</div>
                  </div>
                </div>
                
                <div>
                  <div className="font-semibold text-xl mb-1.5 group-hover:text-[#ff6b00] transition-colors">{shot.title}</div>
                  <div className="text-white/60 leading-snug text-sm">{shot.desc}</div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="text-center mt-16 text-xs text-white/50">
          Real screenshots coming soon • Currently using high-fidelity design mockups
        </div>
      </div>
    </div>
  );
};

// Download Page
const Download = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-12">
          <div className="text-[#ff6b00] text-sm tracking-[3px] mb-2">FRANK-NEXUS-AI v1.0</div>
          <h2 className="text-6xl font-bold tracking-tighter mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-white/70">Choose your platform and start experiencing the future of intelligent assistance.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          {/* Web */}
          <div className="glass p-8 rounded-3xl border border-white/10">
            <div className="text-5xl mb-6">🌐</div>
            <div className="font-semibold text-2xl mb-2">Web</div>
            <div className="text-white/60 mb-8">Works instantly in any modern browser</div>
            <a href="#" className="btn-primary w-full py-3 rounded-2xl block text-center">Open in Browser</a>
          </div>

          {/* Android */}
          <div className="glass p-8 rounded-3xl border border-white/10">
            <div className="text-5xl mb-6">🤖</div>
            <div className="font-semibold text-2xl mb-2">Android</div>
            <div className="text-white/60 mb-8">Native APK available for Android devices</div>
            <a href="#" className="btn-primary w-full py-3 rounded-2xl block text-center">Download APK</a>
          </div>

          {/* Desktop */}
          <div className="glass p-8 rounded-3xl border border-white/10 opacity-75">
            <div className="text-5xl mb-6">💻</div>
            <div className="font-semibold text-2xl mb-2">Desktop</div>
            <div className="text-white/60 mb-8">Coming soon for Windows, macOS & Linux</div>
            <button disabled className="w-full py-3 rounded-2xl border border-white/20 text-white/40">Coming Soon</button>
          </div>
        </div>

        <div className="mt-12 text-sm text-white/50">
          All versions are free • Open source • Privacy respecting
        </div>
      </div>
    </div>
  );
};

// Contact Page with Form
const ContactPage = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      alert('Please fill out all fields.');
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      alert('Please enter a valid email address.');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission (no real backend)
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
      
      // Reset after showing success
      setTimeout(() => {
        setSubmitted(false);
      }, 3000);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-2xl mx-auto px-6">
        <div className="text-center mb-12">
          <div className="text-[#ff6b00] text-sm tracking-[3px] mb-2">GET IN TOUCH</div>
          <h1 className="text-5xl font-bold tracking-tighter">Contact &amp; Feedback</h1>
          <p className="text-white/70 mt-4 max-w-md mx-auto">Have questions, feedback, or want to contribute? We'd love to hear from you.</p>
        </div>

        <div className="glass p-8 md:p-10 rounded-3xl border border-white/10">
          {submitted ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">✅</div>
              <h3 className="text-2xl font-semibold mb-2">Thank you!</h3>
              <p className="text-white/70">Your message has been received. We'll get back to you soon.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm mb-2 text-white/80">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full bg-white/5 border border-white/20 rounded-2xl px-5 py-3 focus:outline-none focus:border-[#ff6b00]/50 transition-colors"
                  placeholder="Your name"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm mb-2 text-white/80">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-white/5 border border-white/20 rounded-2xl px-5 py-3 focus:outline-none focus:border-[#ff6b00]/50 transition-colors"
                  placeholder="your@email.com"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm mb-2 text-white/80">Message</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className="w-full bg-white/5 border border-white/20 rounded-3xl px-5 py-4 focus:outline-none focus:border-[#ff6b00]/50 transition-colors resize-y"
                  placeholder="Tell us what you think or how we can help..."
                  required
                />
              </div>
              
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full py-4 rounded-3xl font-medium text-lg disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          )}
        </div>

        <div className="mt-8 text-center text-xs text-white/50">
          This form is for demonstration. Messages are not stored without a backend configuration.
        </div>
      </div>
    </div>
  );
};

// Privacy Policy Page
const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-3xl mx-auto px-6">
        <div className="mb-12">
          <div className="text-[#ff6b00] text-sm tracking-[3px] mb-2">LEGAL</div>
          <h1 className="text-5xl font-bold tracking-tighter">Privacy Policy</h1>
          <p className="text-white/60 mt-3">Last updated: July 2026</p>
        </div>

        <div className="prose prose-invert max-w-none space-y-8 text-[15px] leading-relaxed">
          <div>
            <h3 className="text-2xl font-semibold mb-4">Your Privacy Comes First</h3>
            <p>FRANK-NEXUS-AI was built with one core principle: <strong>you stay in control</strong>.</p>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-3">Permission-Based Access</h3>
            <p>FRANK-NEXUS-AI never bypasses your device's security. Before accessing any protected feature (Camera, Microphone, Files, Photos, Contacts, Location, Notifications, etc.), the application clearly explains:</p>
            <ul className="list-disc pl-6 mt-3 space-y-1 text-white/80">
              <li>What it wants to access</li>
              <li>Why it needs access</li>
              <li>What data will be used</li>
            </ul>
            <p className="mt-3">You can choose <strong>Allow Once</strong>, <strong>Always Allow</strong>, or <strong>Deny</strong> at any time.</p>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-3">Data Protection</h3>
            <ul className="list-disc pl-6 space-y-2 text-white/80">
              <li>All your data (memories, reminders, notes, preferences) is stored locally in your browser.</li>
              <li>Nothing is sent to external servers without your explicit action.</li>
              <li>No telemetry or tracking is performed.</li>
              <li>You can delete all data at any time by clearing browser storage.</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-3">User Control</h3>
            <p>Through the Owner Control Room, you have full visibility and control over:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1 text-white/80">
              <li>Which permissions are granted</li>
              <li>Your saved memories</li>
              <li>Activity history and logs</li>
              <li>Backup and restore of your data</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-3">Security Practices</h3>
            <p>FRANK-NEXUS-AI uses industry-standard practices for a client-side application:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1 text-white/80">
              <li>No hardcoded credentials or backdoors</li>
              <li>All sensitive actions are gated behind explicit permission requests</li>
              <li>Owner dashboard is password protected</li>
              <li>Transparent activity logging</li>
            </ul>
          </div>

          <div className="pt-6 border-t border-white/10 text-sm text-white/70">
            If you have any questions about privacy, please contact the creator directly.
          </div>
        </div>
      </div>
    </div>
  );
};

// About Page
const About = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pt-20 pb-24">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold tracking-tighter mb-4">Built with Purpose</h2>
        </div>

        <div className="glass p-10 rounded-3xl border border-white/10">
          <div className="mb-8">
            <div className="text-[#ff6b00] text-sm tracking-[2px] mb-1">CREATED BY</div>
            <div className="text-4xl font-bold">Niyikora Frank</div>
          </div>

          <div className="prose prose-invert text-lg text-white/80">
            <p>FRANK-NEXUS-AI was created with one clear mission:</p>
            <p className="font-medium text-white mt-6">
              To build an intelligent assistant that helps users stay productive, organized, and informed 
              while respecting privacy and requiring permission before sensitive actions.
            </p>
          </div>

          <div className="mt-12 pt-8 border-t border-white/10 text-sm text-white/60">
            Version 1.0 • Released 2026 • Designed for the future of human-AI collaboration.
          </div>
        </div>
      </div>
    </div>
  );
};

// Contact / Footer
const Contact = () => {
  return (
    <div className="bg-[#0a0a0f] border-t border-white/10 py-16 text-center text-sm text-white/50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="mb-8">
          <div className="font-semibold text-white mb-1">FRANK-NEXUS-AI</div>
          <div>Intelligence. Privacy. Control.</div>
        </div>
        
        <div className="flex justify-center gap-8 mb-8 text-xs">
          <a href="#" className="hover:text-white">GitHub</a>
          <a href="#" className="hover:text-white">Documentation</a>
          <Link to="/privacy" className="hover:text-white">Privacy Policy</Link>
        </div>

        <div>© {new Date().getFullYear()} Niyikora Frank. All rights reserved.</div>
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <div className="bg-[#0a0a0f] text-white min-h-screen">
        <Navbar />
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/features" element={<Features />} />
          <Route path="/screenshots" element={<Screenshots />} />
          <Route path="/download" element={<Download />} />
          <Route path="/about" element={<About />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>

        <Contact />
      </div>
    </Router>
  );
}

export default App;